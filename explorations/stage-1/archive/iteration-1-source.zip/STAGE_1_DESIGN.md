# RP Usados — Etapa 1: identidad antes del 3D

**Propuesta para revisión · 23 de septiembre de 2026. No autoriza la Etapa 2.**

La recomendación es construir una identidad a partir del lugar real: presencia cinematográfica al entrar, claridad editorial para elegir un auto y cercanía concreta al contactar. La fachada aporta reconocimiento; el catálogo aporta utilidad. La primera candidata tipográfica es **Bricolage Grotesque + Manrope**, sin cerrar la decisión.

## Material para evaluar

- [Comparador interactivo local](http://127.0.0.1:9411/explorations/stage-1/): A/B/C sobre el mismo HTML, contenido, tamaños, pesos, grilla, fotografías y controles. Requiere que el servidor local esté activo.
- [Archivo del comparador](explorations/stage-1/index.html): también se puede abrir directamente en un navegador; no necesita instalar dependencias.
- [A — apertura](explorations/stage-1/review/a-opening.png), [B — apertura](explorations/stage-1/review/b-opening.png), [C — apertura](explorations/stage-1/review/c-opening.png).
- [A — catálogo](explorations/stage-1/review/a-catalog.png), [B — catálogo](explorations/stage-1/review/b-catalog.png), [C — catálogo](explorations/stage-1/review/c-catalog.png).
- [Vista mobile A](explorations/stage-1/review/a-390.png), [ficha de muestra](explorations/stage-1/review/detail-desktop.png).
- [Verificación y límites de la exploración](explorations/stage-1/REVIEW.md): 12 combinaciones de tipografía/ancho, interacción, teclado, contraste y build.

Los espacios de fotografías de unidades son intencionales. No hay stock conectado ni autos inventados. «Marca / Modelo», «AAAA» y «00.000 km» son patrones tipográficos de desarrollo, identificados como tales; no pueden publicarse como datos comerciales. Para información real faltante se mantiene `[dato pendiente — confirmar con el cliente]`.

### Alcance y base técnica comprobada

Se mantiene WordPress sin WooCommerce, tema clásico PHP, CPT `vehiculo`, administración nativa y Vite. Se reutilizarán registro y lectura de vehículos, saneamiento, permisos/nonces, protección del precio y generación de WhatsApp por unidad. No se han modificado esos archivos.

El archivo de vehículos actual pagina a 12 unidades y admite disponibles/reservados; excluye vendidos. La Home actual consulta tres destacados. La dirección nueva reemplazará esa presentación por el catálogo completo cuando corresponda implementar, según lo pedido; **esta etapa no cambia consultas ni elimina campos administrativos**. No hace falta migrar a React, agregar un backend ni reemplazar WordPress.

Skills utilizadas: `frontend-design-codex` para dirección, composición y prueba visual; `ui-ux-pro-max` para lectura, touch, teclado, estados y responsive. `imagegen` se usó exclusivamente para un estudio raster de iluminación. No se usaron skills de frontend redundantes, Blender, Three.js ni nuevas dependencias del tema.

## A. Concepto visual refinado

### Un lugar de siempre. Una nueva forma de elegir.

La propuesta tiene tres momentos reconocibles:

1. **Reconocer el negocio:** su esquina real, a altura humana, con la marca legible y una iluminación sobria. El diferencial no es mostrar un edificio lujoso inexistente; es convertir un lugar identificable en una imagen cuidada.
2. **Mirar los autos:** se abre una superficie clara, amplia y ordenada. La escala de las fotos, los títulos y los datos hacen el trabajo comercial.
3. **Encontrarse:** historia confirmada, posibilidades de pago y una dirección concreta. El cierre invita a conversar o visitar; no sugiere compra online.

La propuesta de voz es directa, rioplatense y contenida: «Encontrá tu próximo auto», «Tu usado, parte de pago», «El próximo paso es una charla». Son textos propuestos; no agregan garantías, certificaciones, tasas, atención personalizada, reseñas ni beneficios no confirmados.

La trayectoria se expresa como «Desde 1990» y, cuando ayude, «36 años de trayectoria» a 2026. Evitar un gran contador decorativo como protagonista de toda la Home. La dirección anterior no se conserva como identidad obligatoria.

## B. Sistema visual

### Color y superficies

Los siguientes son **tokens propuestos para la interfaz**, no mediciones de pintura ni una nueva paleta para el edificio.

| Rol | Propuesta | Aplicación |
| --- | --- | --- |
| Papel cálido | `#F5F3EE` | Catálogo, ficha, lectura y contacto. Evita que el blanco se vuelva clínico. |
| Tinta | `#222725` | Texto y CTA principal. Oscuro levemente cálido, sin negro puro dominante. |
| Texto secundario | `#58605B` | Ayudas y metadatos sobre papel. No usar gris demasiado tenue. |
| Noche | `#172325` | Entorno de la apertura, no bloques oscuros repetidos. |
| Superficie mineral | `#E5E7E0` | Financiación/permutas y ayudas puntuales. |
| Separador | `#C9CCC5` | Divisiones decorativas; no alcanza por sí solo para delimitar un control. |
| Foco | `#175DA3` | Foco de teclado visible sobre superficies claras; sobre noche usar un foco claro contrastante. |
| Luz cálida | `#E7AE79` | Acento mínimo de atmósfera. No convertirlo en una marca naranja. |

Los controles usan un borde más oscuro que los separadores. Estados disponible/reservado se reconocen por texto, además del color. No asignar «reservado» a un botón de reserva online.

El rojo no desaparece del branding real si el logo original lo incluye, pero no se usa como relleno dominante de toda la interfaz. La paleta anterior era provisional. **Esta propuesta de color necesita tu aprobación.** El acceso de la esquina sigue negro, los paños gris claro y el zócalo gris oscuro; la iluminación puede teñir la luz incidente sin cambiar el material base.

Sin glassmorphism, fondos de degradado ornamentales, sombras de tarjeta ni contenedores redondeados en cada sección. Las fotos son rectangulares; el círculo se reserva a controles breves como siguiente/cerrar. Botones de borde casi recto. Las superficies se diferencian por escala, espacio y material visual, no por efectos.

### Grid, escala y ritmo

- Contenido máximo orientativo: 1.392 px, márgenes fluidos de 20–72 px. Grilla conceptual de 12 columnas desktop, 8 tablet, 4 mobile.
- Desktop: catálogo de 3 columnas; tablet de 2 cuando cada unidad conserve lectura cómoda; mobile de 1. No forzar 3 columnas en todo ancho intermedio.
- Escala espacial: 4, 8, 12, 16, 24, 32, 48, 64, 96. Separaciones entre secciones de 56–100 px según dispositivo y contenido.
- Titular de apertura: 44–76 px; títulos de sección: 36–52 px; vehículo: 25–28 px; cuerpo comercial: 16–18 px; metadatos: 12–14 px. Las notas de la mesa de trabajo son menores y no definen el tamaño de lectura comercial final.
- Ancho de párrafo de 45–68 caracteres aproximadamente. Interlineado de cuerpo 1,5–1,65. Mayúsculas sólo en etiquetas breves.

El ritmo propuesto: escena densa → catálogo claro y preciso → fotografía real con texto editorial → franja de dos alternativas comerciales → contacto abierto → ubicación fotográfica. La repetición ordenada se reserva al catálogo porque ayuda a comparar.

### Fotografía, botones y navegación

Fotografías de vehículos en 3:2, misma escala visual y punto de vista exterior de tres cuartos. Mantener ruedas, paragolpes y techo completos. Fondo real tranquilo, luz pareja, color fiel, sin agregar brillos o desperfectos ni alterar el estado del vehículo. No oscurecer fotos comerciales para hacerlas combinar con el hero.

La ficha permite ver el encuadre completo; no debe depender de recortes de portada. La foto del local prueba presencia física. El estudio nocturno comunica atmósfera, pero no sustituye esas fotos como evidencia del estado real.

Navegación corta: Vehículos, Nosotros, Financiación y permutas, Hablemos. Contacto y Ubicación siguen siendo destinos identificables. CTA principal con verbo concreto y superficie sólida; secundario como enlace subrayado. No duplicar cinco botones de igual importancia en el hero.

El rótulo tipográfico RP USADOS de la exploración es un placeholder, **no un rediseño aprobado del logo**. Se reemplaza por el archivo de marca confirmado.

## C. Comparación tipográfica con la misma composición

El comparador no son tres webs. Las rutas cambian dos variables CSS de familia. Se mantienen tamaños, peso 600 de títulos, tracking, anchos y contenido. Los cambios naturales en saltos de línea se dejan visibles: también son una característica de la fuente. No se achica una ruta para hacerla parecer equivalente.

Se muestran navegación, heading principal, subtítulo, CTA, título de vehículo, año, kilometraje, specs, labels, filtros y texto de cuerpo. La ficha de muestra añade lectura de especificaciones y galería. El cambio funciona con mouse y teclado; la ruta elegida queda en `?ruta=a|b|c`.

| Uso | A: Bricolage + Manrope | B: Newsreader + Instrument | C: Manrope + Archivo |
| --- | --- | --- | --- |
| Titulares y títulos de unidad | Bricolage Grotesque 600 | Newsreader 600, romana | Manrope 600 |
| Cuerpo y subtítulo | Manrope 400–500 | Instrument Sans 400–500 | Archivo 400–500 |
| Navegación, CTA, filtros | Manrope 500–600 | Instrument Sans 500–600 | Archivo 500–600 |
| Labels | Manrope 600 | Instrument Sans 600 | Archivo 600 |
| Año, km y especificaciones | Manrope 500 | Instrument Sans 500 | Archivo 500 |
| Sensación | Contemporánea, humana, con carácter | Editorial, tranquila, distinguida | Precisa, estable, funcional |
| Relación automotriz | Carácter técnico suavizado; sirve a stock variado | Mirada de marca y cultura del auto; menos lenguaje técnico | Cercana a información técnica y señalética |
| Principal fortaleza | Personalidad sin sacrificar claridad comercial | Diferenciación fuerte y buena narrativa institucional | Legibilidad práctica y menor peso |
| Principal debilidad | Puede parecer demasiado expresiva si se extiende a toda la UI | Puede acercarse a editorial de lifestyle; mayor peso | Dos sans de roles próximos; menor contraste y singularidad |
| Una o dos familias | Dos tienen función clara. Bricolage no debe llenar todos los labels. | Dos necesarias para este contraste. Newsreader sola no es mi elección para controles. | Dos en la prueba pedida; Manrope sola sería una simplificación posible después. |

Para números se propone `font-variant-numeric: tabular-nums lining-nums`, comprobar cobertura de la versión final y no depender de ello para alinear columnas: la grilla conserva la comparación. Probar km extensos, acentos, Ñ, signos de consulta y títulos largos con datos reales antes del cierre.

### Variables, licencia y peso real descargado

| Familia | Variable disponible en Google Fonts | Ejes publicados de la familia | WOFF2 latino de esta prueba |
| --- | --- | --- | ---: |
| Bricolage Grotesque | Sí | peso 200–800, ancho 75–100, tamaño óptico 12–96 | 75,1 KiB |
| Manrope | Sí | peso 200–800 | 24,3 KiB |
| Newsreader | Sí | peso 200–800 y tamaño óptico 6–72; cursiva aparte | 128,9 KiB |
| Instrument Sans | Sí | peso 400–700 y ancho 75–100; cursiva aparte | 29,4 KiB |
| Archivo | Sí | peso 100–900 y ancho 62–125; cursiva aparte | 34,1 KiB |

Los ejes anteriores describen las familias de origen. La solicitud de esta exploración conserva peso y, donde se pidió, tamaño óptico; usa ancho normal y no descarga cursivas. No asumir que cada WOFF2 descargado incluye todos los ejes de la familia original.

Pesos de transferencia de fuentes, sin CSS y antes de caché: **A 99,4 KiB; B 158,3 KiB; C 58,4 KiB**. Son mediciones de archivos, no estimaciones genéricas. Si se cambian ejes, subconjuntos o versión hay que medir otra vez. La latencia total depende también de conexión, caché y del dispositivo.

Las cinco se distribuyen bajo SIL Open Font License. Están autoalojadas en `explorations/stage-1/fonts/` con copias de OFL, URL de origen, fecha, bytes y SHA-256 en `manifest.json`. El uso comercial y autoalojamiento están contemplados por OFL respetando sus condiciones; conservar avisos de licencia. No se hace una solicitud a Google Fonts desde el comparador.

Fuentes oficiales consultadas: [Bricolage Grotesque](https://github.com/google/fonts/tree/main/ofl/bricolagegrotesque), [Manrope](https://github.com/google/fonts/tree/main/ofl/manrope), [Newsreader](https://github.com/google/fonts/tree/main/ofl/newsreader), [Instrument Sans](https://github.com/google/fonts/tree/main/ofl/instrumentsans), [Archivo](https://github.com/google/fonts/tree/main/ofl/archivo).

### Autoalojamiento futuro

Después de elegir ruta: copiar sólo la familia o pareja elegida a los assets del tema; declarar `@font-face` con WOFF2, rangos de peso correctos y `font-display: swap`; incluir licencia en distribución. Pedir el subconjunto latino que cubra español y probar todos los caracteres de las unidades. Precargar como máximo la fuente crítica del primer titular y, sólo si las mediciones lo justifican, la de cuerpo. Ajustar fallback con métricas para reducir cambios de layout. Servir assets versionados con caché; no cargar las cinco familias en producción.

## D. Recomendación preliminar

**A — Bricolage Grotesque + Manrope** es mi primera candidata. Bricolage aporta una voz reconocible sin obligar a que toda la web se vuelva extravagante; Manrope mantiene precisión y una lectura tranquila en filtros y datos. Es un buen equilibrio para una concesionaria establecida con stock diverso.

Elegiría **B** si querés priorizar una percepción editorial y sofisticada, aceptando su mayor peso y el trabajo extra para evitar una asociación demasiado cercana a una revista. Elegiría **C** si preferís que la identidad sea más contenida y técnica; consideraría entonces si Archivo aporta suficiente diferencia frente a usar Manrope sola.

No propongo una cuarta familia: todavía no hay una ventaja suficientemente clara que justifique ampliar las opciones. Ninguna está seleccionada definitivamente.

## E. Storyboard refinado del hero

### Encuadre y recorrido propuestos

La ochava es el ancla reconocible. Encuadre inicial oblicuo, con ambos frentes visibles, el acceso negro cerca del centro y la cartelería real legible. Usar la fotografía actual de la esquina como guía. Mantener suficientes elementos urbanos para ubicar el local: vereda, cordón, encuentro de calles, semáforo y volumen vecino. No convertir el local en un edificio aislado de catálogo arquitectónico.

Cámara a aproximadamente 1,55–1,70 m del suelo y una óptica equivalente de 35–45 mm como hipótesis inicial. Ajustar en blockout según medidas y encuadre; no son dimensiones deducidas de las fotos. El recorrido avanza hacia la normal del acceso con una corrección lateral suave. Evitar vuelo de dron, atravesar el poste, grandes órbitas, inclinación de horizonte o cambios dramáticos de focal.

| Progreso | Imagen / acción | Ritmo y condición |
| --- | --- | --- |
| 0–20% | Exterior completo reconocible. Texto breve y acceso directo a vehículos. | Momento de orientación; inicio de cámara casi imperceptible. |
| 20–45% | Aproximación. El acceso gana escala; la fachada sigue dando contexto. | Aceleración suave, velocidad contenida. El texto inicial pierde presencia antes de tapar el cartel. |
| 45–70% | Apertura del acceso real. | Comienza al 45%; debe dejar libre el paso al 65–70%. El mecanismo depende de evidencia, no se inventan dos hojas batientes. |
| 70–85% | Cruce breve del umbral. | Aproximadamente 0,6–1 m de ingreso, pendiente de medidas. Se desacelera. Umbral libre, sin atravesar autos o geometría. |
| 85–100% | Solapamiento entre espacio iluminado y catálogo. | La UI aparece antes de extinguirse toda la escena. La cámara se asienta; luego continúa el scroll normal. |

**Longitud inicial propuesta:** 180–220 svh de desplazamiento efectivo asociado a la secuencia en desktop. Con un viewport fijado de 100 svh, el contenedor total sería 280–320 svh; no confundir esas dos medidas. Buscar una lectura de unos 5–8 segundos con desplazamiento cómodo, no imponer una espera de ese tiempo. La persona puede recorrerlo mucho más rápido o saltarlo.

El scroll controla progreso continuo en ambos sentidos. No se captura la rueda ni se fuerza un timeline a terminar. Si se aplica suavizado, será breve, sin que la cámara siga moviéndose varios segundos después de que el usuario pare. Usar una rampa de velocidad de cámara, no múltiples rebotes o easing por cada objeto.

El mecanismo de puerta es un bloqueo de fidelidad para esa toma, no una autorización para inventarlo. Si las fotos/video muestran otro funcionamiento, se adapta el storyboard dentro de este propósito y se revisa antes de producir la animación.

## F. Transición hero → catálogo

La continuidad se construye con **encuadre, luminancia y solapamiento**:

1. Al acercarse al umbral, la zona interior neutra ocupa más pantalla. Debe haber planos y profundidad suficientes para sugerir un lugar real; no un vacío negro ni un túnel abstracto.
2. La iluminación cálida queda localizada cerca de la entrada. La superficie que llena el encuadre se aproxima al papel neutro del catálogo: no hacer un fogonazo blanco o sobreexponer toda la imagen.
3. Entre aproximadamente 82–94%, se funde escena con un fondo DOM de ese tono. El encabezado «Encontrá tu próximo auto» aparece mientras todavía se perciben bordes suaves del espacio. El contenedor de filtros no entra volando desde abajo.
4. Entre 94–100%, encabezado y filtros quedan sólidos, listos para usar. La primera fila tiene posiciones reservadas desde el inicio. Se libera el viewport y continúa la página.

```text
EXTERIOR                 UMBRAL                    CATÁLOGO
Escena 100%              Escena ↓ / DOM ↑           DOM 100%
Marca + CTA              Cámara desacelera           Filtros + vehículos
Frío con luz puntual  →  Superficie neutra ocupa  →   Papel claro
```

El catálogo existe como HTML desde el principio, fuera de WebGL. Sólo su presentación se coordina con la escena; el contenido no se fabrica al terminar el viaje. «Ver vehículos» es un enlace real a `#catalogo`, visible desde el primer instante. Al activarlo debe terminar cualquier fijación, mostrar el catálogo y colocar el foco en su título; no recorrer toda la cámara automáticamente. La navegación por Tab tampoco obliga a esperar.

Con reduced motion, ausencia de WebGL, carga fallida o capacidad limitada: imagen estática y catálogo inmediatamente debajo. No cambiar a 3D si ya empezó la persona a navegar el catálogo. Conservar progreso al volver desde una ficha; no reimponer la apertura.

En esta exploración la separación es deliberadamente estática: el boceto de portada sirve a la tipografía. **No pretende validar la continuidad cinematográfica**, que habrá que probar con el blockout aprobado.

## G. Concepto del catálogo y la ficha

### Catálogo completo

Una única sección comercial principal, con todas las unidades elegibles. Estimación del cliente: 20–30; el contador futuro debe usar resultados reales, no ese número fijo. Se propone mostrar el conjunto en una página para ese volumen, con fotos diferidas después de la primera fila. El archivo actual pagina a 12: adaptar presentación y consulta será trabajo posterior, sin cambiar modelo de contenido ni romper su funcionamiento sin JavaScript.

Fotos dominantes, título y versión debajo, luego una línea comparativa de año y kilometraje. Sin precio, precio tachado, cuota sugerida, «desde», datos de precio en JSON auxiliar ni precio en relacionados. «Reservado» sigue visible como estado textual; los vendidos no participan en listado ni opciones de filtro. No incluir un filtro de estado adicional sin necesidad aprobada.

**Filtros:** búsqueda marca/modelo; marca; año. Combinados con lógica AND. Opciones de marca/año derivadas del stock elegible. Un selector «Año» por valor existente basta inicialmente; no agregar rangos, transmisión o combustible ahora. Buscar mediante envío explícito permite una experiencia coherente con teclado y touch, sin solicitudes por cada tecla.

Futura base: GET y respuesta del servidor, URL compartible, búsqueda que conserve valores al volver de la ficha. Si se añade mejora AJAX, conservar URL, foco y anuncio del total de resultados; evitar reemplazar todo el contenido sin feedback. Para 20–30 unidades no hacen falta virtualización ni un motor externo.

| Estado | Tratamiento propuesto |
| --- | --- |
| Cargando filtrado mejorado | Mensaje breve «Buscando…», altura estable, botón con estado ocupado. No inventar esqueletos de resultados. |
| Sin coincidencias | Explicar que los filtros no encontraron unidades y ofrecer limpiar. |
| Sin stock publicado | Estado editorial claro, invitación a consultar con contacto validado. No mostrar unidades falsas. |
| Foto faltante | Espacio reservado y etiqueta honesta. No stock photos de un vehículo similar. |
| Reservado | Etiqueta visible, misma lectura de ficha; no afirmar disponibilidad para entrega. |
| Vendido por enlace antiguo | Mantener la política funcional existente y estado visible; no volver a introducirlo en catálogo. |
| Error de mejora JS | Formulario y navegación del servidor siguen funcionando. |

### Ficha individual

URL propia por unidad. En desktop, galería amplia a la izquierda y resumen de compra a la derecha; precio sólo aquí, datos reales y CTA de WhatsApp que identifica título y URL. Debajo, especificaciones en filas, descripción legible y condiciones únicamente confirmadas. No inventar inspecciones, garantía ni financiación específica para una unidad.

Mobile: título/estado, galería, precio y resumen, CTA y resto de información. Botón de consulta cercano al pulgar; si se fija al borde inferior, reservar espacio, respetar safe area y no tapar información. Navegación de galería con botones accesibles, además de swipe si se implementa. Nada exige hover.

La ficha modal de la exploración es sólo una herramienta para ver tipografía, jerarquía y feedback. **No propone cambiar las fichas públicas a modales**. El precio de la muestra permanece como dato pendiente; no se usó un importe ficticio.

## H. Concepto visual del resto de la Home

| Sección | Composición | Qué aporta y qué evitar |
| --- | --- | --- |
| Nosotros / por qué elegirnos | Díptico asimétrico: foto actual amplia y texto más estrecho. «Desde 1990» como dato editorial. | Lugar y trayectoria verificables. Sin cards de beneficios inventados, retratos de equipo falsos ni cifras de clientes. |
| Financiación y permutas | Franja mineral, título en una columna y dos filas con divisores en la otra. | Dos caminos claros con un acceso a conversación. Sin simulador, tasa, anticipo, aprobación o cuota no confirmados. |
| Contacto | Composición abierta, titular amplio y un CTA principal con ayuda breve. | Reduce fricción. WhatsApp pendiente se señala en exploración; la publicación requiere número confirmado. No agregar formulario y tratamiento de datos por defecto. |
| Ubicación | Dirección tipográfica + foto reconocible del acceso; enlace externo a Maps. | Facilita visita y reduce carga. Mapa embebido sólo si luego aporta algo concreto; no es necesario para encontrar el local. |

Contacto y ubicación forman un cierre relacionado visualmente, con anclas propias; no se elimina ninguna sección solicitada. No agrego testimonios, blog, marcas asociadas, comparador de autos, favoritos, formulario de tasación ni contenidos no pedidos.

## I. Sistema de animaciones y microinteracciones

Un solo lenguaje: cambios breves, distancias cortas, respuesta inmediata. CSS para estado/hover; Web Animations sólo si coordinar una transición concreta lo vuelve más claro. GSAP, ya presente como dependencia en el proyecto, se reservará para el recorrido del futuro hero; no se añadió ni se usó en esta prueba.

| Interacción | Propuesta futura | Reduced motion / touch |
| --- | --- | --- |
| Vehículo al hover | Imagen hasta 1,015× en 180–220 ms y cambio discreto del enlace. Sin inclinar tarjeta. | Foto quieta; enlace siempre visible. No segunda foto exclusiva del hover. |
| Navegación | Subrayado en 140–180 ms; estado actual visible sin movimiento. | Cambio inmediato. |
| Botones | Fondo/borde 120–160 ms; feedback pressed breve. | Igual información sin animación. |
| Filtros | Sin mover el formulario; resultados cambian con una disolución de 120–180 ms si hay mejora JS. | Sustitución directa y anuncio accesible. |
| Galería | Cambio/crossfade 160–220 ms, dimensiones estables y contador. | Cambio directo; botones 44–48 px. |
| Carga de fotografías | Espacio reservado; aparición breve sólo después de decodificar. | Imagen directa; nunca esconder indefinidamente esperando JS. |
| Revelado institucional | Opcional, una vez, opacidad y hasta 8 px en 180–240 ms. | Contenido visible desde el inicio. |

No habrá animación ambiente permanente, cursores personalizados, parallax general, autoplay de galería, cascadas de cada tarjeta ni delays artificiales. La primera fila del catálogo no espera un reveal. El máximo movimiento importante pertenece al hero y puede saltarse.

La exploración implementa solamente cambios de botones/enlaces, alternancia de fuentes, respuesta de filtros y galería/ficha de muestra. No implementa los futuros reveals ni el movimiento de cámara.

## J. Estrategia responsive / mobile

### Qué se mantiene

Mismo local reconocible, proporción fría/cálida, tipografía elegida, jerarquía, fotos fieles, precio sólo en ficha y acceso al catálogo/consulta. La identidad proviene de esos elementos, no de que todo teléfono ejecute un render complejo.

### Qué cambia

- **Mobile recomendado: 2.5D opcional sobre una imagen aprobada, no WebGL por defecto.** Capas poco numerosas con movimientos mínimos; no simular una entrada completa atravesando una foto plana. Apertura/cámara completa puede quedarse en desktop.
- Encuadre vertical específico que conserve acceso y un tramo de ambas fachadas. La fotografía original ya ayuda a verificarlo. No recortar un render horizontal hasta perder la esquina.
- Propuesta de recorrido móvil de 60–100 svh como máximo, si las pruebas justifican animación. Base estática cuando haya reduced motion, ahorro de datos detectable, bajo rendimiento o preferencia del navegador. No confiar sólo en el ancho ni asumir que todos los teléfonos son débiles.
- CTA de catálogo inmediatamente visible y navegación corta que envuelve de forma ordenada. El comparador muestra enlaces explícitos; no hace falta ocultarlos tras un menú complejo.
- Catálogo de una columna en teléfono; dos sólo cuando el ancho permita título, estado y datos legibles. Imágenes 3:2 y espacios touch claros.
- Filtros: búsqueda de ancho completo, marca/año debajo, botón Buscar completo. Sin drawer obligado ni chips interminables. Selects nativos para empezar.
- Ficha: recorrido vertical y galería accesible. El CTA fijo inferior se evaluará en ficha, no como una segunda barra permanente compitiendo con toda la Home.

### Presupuestos orientativos para etapas futuras

Estos son **criterios de aceptación propuestos**, no resultados de una escena que aún no existe:

| Recurso / métrica | Objetivo |
| --- | --- |
| HTML + CSS + JS inicial, excluyendo 3D | ≤180 KiB comprimidos como punto de partida, antes de terceros; revisar con build real. |
| Fuentes de producción | Preferido ≤110 KiB para A/C; aceptar hasta 160 KiB si se elige B por valor visual. Dos familias como máximo. |
| Poster inicial | 150–300 KiB mobile; ≤400 KiB desktop en formato moderno si conserva calidad. |
| 2.5D mobile | ≤600 KiB totales en imágenes/capas para el hero; fallback de una sola imagen. |
| Escena desktop futura | Objetivo ≤3 MiB transferidos, techo provisional 4 MiB con geometría y texturas; decodificadores/runtime aparte y medidos. |
| Texturas dentro de escena | Objetivo ≤2 MiB transferidos; presupuesto GPU separado, ≤128 MiB orientativo. No confundir compresión con memoria GPU. |
| Movimiento | 60 FPS ideal desktop; 30 FPS sostenidos como mínimo para decidir continuidad de la escena. Si no, simplificar o usar poster. |
| Web funcional | Objetivos LCP ≤2,5 s, INP ≤200 ms, CLS ≤0,1 en medición representativa; validar en teléfono real y red limitada. |

La implementación futura priorizará texto, navegación y poster. Cargar módulo y escena fuera del camino crítico, sin bloquear catálogo; detener render fuera de vista y al ocultarse la pestaña. Antes de imponer LOD, medir si una geometría única reducida basta. Texturas comprimidas y luz precalculada se evaluarán en la fase de escena; no son dependencias agregadas ahora.

**La imagen PNG de esta exploración pesa aproximadamente 2,5 MiB y está sin optimizar para distribución.** Es material de revisión local, no cumple el presupuesto de poster y no debe copiarse tal cual a producción. Las capturas largas de QA tampoco son assets del sitio.

## K. Assets faltantes antes del blockout 3D

Las tres fotografías actuales y las capturas de Street View ya sirven para volúmenes iniciales. Para resolver el acceso y evitar inventar proporciones necesitamos las siguientes referencias. Tomarlas desde lugares seguros, sin ponerse en la calzada para obtener un encuadre.

| Prioridad | Toma / dato | Ángulo, distancia y detalle buscado |
| --- | --- | --- |
| Crítica para el recorrido | Acceso de la ochava cerrado, parcialmente abierto y abierto; video breve del mecanismo | Cámara frontal a la puerta, horizontal, aproximadamente 2–4 m si hay lugar seguro. Mostrar hojas, guías, bisagras y hacia dónde se desplazan. Sin mover cámara durante la apertura. |
| Crítica para escala | Ancho libre y alto del acceso; ancho de ochava | Cinta/medida confirmada. No inferir metros a partir de tamaño de autos. Con una escala confiable se ajustan las referencias. |
| Alta | Frente largo perpendicular | Horizontal, desde la vereda opuesta, aproximadamente 10–18 m según condiciones seguras. Cámara nivelada, sin ultra gran angular; incluir base y borde superior. |
| Alta | Frente del portón perpendicular | Igual criterio, portón entero, encuentro con ochava y estructura superior visibles. Una toma con portón cerrado y otra abierto. |
| Alta | Ambas diagonales de la esquina | Dos fotos a 30–45° hacia cada fachada, desde posiciones seguras. Altura de cámara cercana a 1,60 m. No sólo una panorámica deformada. |
| Alta | Umbral hacia adentro | Desde la puerta, horizontal, y otra aproximadamente 1 m adentro sólo con autorización del dueño. Piso, techo inmediato, laterales y primeros 2–3 m; no hace falta todo el showroom. |
| Alta | Cartel y marca | Foto frontal nítida a 2–4 m o distancia segura equivalente; detalle del óvalo, letras y bordes. Logo original SVG/PDF/vector si existe; no reconstruir letras desde la generación. |
| Media | Materiales | Paño gris, zócalo, negro del acceso, reja/vidrio y vereda a 0,5–1,5 m, con luz pareja. Una toma con referencia neutra ayuda a distinguir pintura de dominante de luz. |
| Media | Iluminación real | Misma esquina a blue hour y de noche, luces existentes encendidas. Exposición que conserve cartel y fachada; evitar modo nocturno muy procesado. |
| Media | Croquis / medidas adicionales | Ancho aproximado de ambos frentes, altura de fachada y profundidad disponible inmediata. Croquis simple del dueño si no hay plano. |

No hace falta fotografiar techo desde arriba, acceder a lugares riesgosos ni un dron. El tanque y volúmenes visibles se resuelven desde suelo; lo no visible no necesita detalle.

### Assets comerciales posteriores

Fotos y datos confirmados de cada unidad; identificación de disponibles/reservadas; logo original; WhatsApp; horarios; condiciones comerciales que el cliente quiera publicar. Los datos faltantes mantienen el marcador obligatorio. No son necesarios para elegir tipografía, pero sí para validar la densidad real y para publicar.

Para autos: exterior de tres cuartos delantero, lateral y trasero, interior general y detalles relevantes, horizontal y luz pareja. Conservar archivos originales. No usar la hoja de cálculo de una captura ni los autos de las fotos del edificio como inventario validado.

### Límite del estudio generado

El estudio 2D conserva la idea de gris/negro y la esquina, pero modifica detalles finos de cartelería, exposición y algunos elementos interiores. También acentúa la luz de varias aberturas. **Se aprueba, si corresponde, sólo su relación de atmósfera; no esos detalles ni una obra de iluminación real.** Para producción propongo calidez menos intensa y más localizada. No usarlo para medir, texturizar letras, deducir interior ni decidir luminarias.

La original permanece intacta en `references/local-2026-09-22/dueno-03-esquina.jpeg`. La derivada separada está en `explorations/stage-1/media/blue-hour-study.png`. Se generó con la herramienta integrada Image Gen usando esa única foto. El prompt pidió conservar cámara, geometría, aberturas, carteles, superficies, vehículos y contexto, cambiando sólo iluminación hacia blue hour y prohibiendo neón/infraestructura nueva. La revisión detectó las desviaciones descritas; no se presentan como fieles.

## L. Riesgos, criterios de aprobación y siguiente etapa

| Riesgo | Resolución propuesta |
| --- | --- |
| Entrada poco fiel o imposible | Obtener mecanismo y medidas; aprobar cámara sobre blockout antes de materiales. |
| Hero hermoso pero fricción comercial | Link de salto, catálogo SSR, carga desacoplada y prueba del tiempo hasta primer vehículo. |
| Mobile pierde identidad | Mismo encuadre/iluminación/tipo con poster o 2.5D corto; no versión 3D degradada automáticamente. |
| Demasiada oscuridad / luz cálida | Fachada gris legible, negro con detalle, calidez localizada; no adoptar la exposición generada sin revisión. |
| Tipografía cambia con títulos reales | Validar marcas/modelos largos, acentos y números con inventario confirmado. |
| Cambiar precios o WhatsApp al rediseñar | Reutilizar lógica actual y agregar regresiones en etapa de integración. Nunca precio en listado. |
| Estudio se confunde con web terminada | Carpeta separada, aviso visible, noindex, sin publicación ni cambios del tema. |

La Etapa 2 debería comenzar sólo tras las decisiones siguientes y tener un primer entregable reversible: blockout gris con escala, mecanismo del acceso y cámaras para desktop/mobile. Antes de materiales finales o integración se revisará reconocimiento del lugar y continuidad de entrada. Este documento no ejecuta esa etapa ni autoriza escenas adicionales.

## DECISIONES QUE NECESITO DEL USUARIO PARA PASAR A LA ETAPA 2

1. **Ruta tipográfica:** A, B o C; o ajustes concretos sobre una de ellas. Mi recomendación preliminar es A. Si elegís C y querés simplificar a Manrope sola, esa variante se valida antes de adoptarla.
2. **Dirección visual de la UI:** aprobar o ajustar papel cálido, tinta, superficies minerales, catálogo fotográfico sin cajas y composiciones propuestas. Esto reemplaza la estética anterior; no modifica los colores reales de la fachada.
3. **Objetivo del blockout y ritmo:** aprobar la secuencia descrita, el rango de scroll desktop y la entrada breve, condicionada al mecanismo real. Mantener el salto inmediato al catálogo. La intensidad cálida propuesta para producción será menor que la del estudio generado.
4. **Mobile:** aprobar poster como base y 2.5D breve como mejora opcional, sin exigir la entrada 3D completa en teléfonos.

Con esas decisiones y tu autorización explícita para pasar a la Etapa 2, se prepara el blockout. La elección fina de tecnología 3D e integración seguirá siendo una propuesta revisable en esa fase; aquí no se agrega ninguna librería ni se inicia Blender.
