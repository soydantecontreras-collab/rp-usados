import { createRequire } from 'node:module';
import { mkdir, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
const require = createRequire('C:/Users/dante.DESKTOP/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/package.json');
const { chromium } = require('playwright');
const out = resolve('explorations/stage-1/review');
await mkdir(out, { recursive: true });
const browser = await chromium.launch({ channel: 'msedge', headless: true });
const results = [];
const base = 'http://127.0.0.1:9411/explorations/stage-1/';
try {
  for (const route of ['a', 'b', 'c']) {
    for (const width of [1440, 768, 390, 320]) {
      const page = await browser.newPage({ viewport: { width, height: 1000 }, reducedMotion: 'reduce' });
      const errors = [];
      page.on('pageerror', err => errors.push(err.message));
      const response = await page.goto(base + '?ruta=' + route, { waitUntil: 'networkidle' });
      await page.evaluate(() => document.fonts.ready);
      await page.evaluate(async () => { for (const img of document.images) { img.loading = 'eager'; } await Promise.all([...document.images].map(img => img.decode().catch(() => {}))); });
      const state = await page.evaluate(() => ({
        overflow: document.documentElement.scrollWidth > innerWidth,
        route: document.documentElement.dataset.route,
        display: getComputedStyle(document.querySelector('h1')).fontFamily,
        body: getComputedStyle(document.body).fontFamily,
        fonts: [...document.fonts].filter(f => f.status === 'loaded').map(f => f.family),
        heroWidth: document.querySelector('.opening').getBoundingClientRect().width,
        gridColumns: getComputedStyle(document.querySelector('.vehicle-grid')).gridTemplateColumns,
        scrollBehavior: getComputedStyle(document.documentElement).scrollBehavior,
        badImages: [...document.images].filter(i => i.complete && !i.naturalWidth).length,
      }));
      if (state.overflow || errors.length || state.route !== route || response.status() !== 200 || state.badImages) throw new Error(JSON.stringify({ route, width, state, errors }));
      await page.keyboard.press('Tab');
      if (!await page.locator('.skip').evaluate(el => el === document.activeElement)) throw new Error('Skip focus failed');
      if (width === 1440 || width === 390) {
        await page.locator('h1').click();
        await page.screenshot({ path: resolve(out, `${route}-${width}.png`), fullPage: true });
        if (width === 1440) {
          await page.locator('#catalogo').screenshot({ path: resolve(out, `${route}-catalog.png`) });
          await page.locator('.opening').screenshot({ path: resolve(out, `${route}-opening.png`) });
        }
        if (route === 'a') {
          await page.locator('.about').screenshot({ path: resolve(out, `about-${width}.png`) });
          if (width === 390) {
            await page.locator('.opening').screenshot({ path: resolve(out, 'mobile-opening.png') });
            await page.locator('.vehicle').first().screenshot({ path: resolve(out, 'mobile-vehicle.png') });
          }
        }
      }
      results.push({ route, width, ...state, errors });
      await page.close();
    }
  }
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  await page.goto(base, { waitUntil: 'networkidle' });
  await page.locator('input[value=b]').check();
  if (await page.locator('html').getAttribute('data-route') !== 'b') throw new Error('Route switch failed');
  await page.locator('#search').fill('Prueba de filtro');
  await page.locator('#filters button').click();
  if (!(await page.locator('#filter-feedback').textContent()).includes('Filtro probado')) throw new Error('Filter feedback failed');
  await page.locator('#reset').click();
  if (await page.locator('#search').inputValue()) throw new Error('Reset failed');
  await page.locator('[data-open-detail]').nth(1).click();
  if (!(await page.locator('#detail-state').textContent()).includes('Reservado')) throw new Error('Reserved state failed');
  await page.locator('#gallery-next').click();
  if (!(await page.locator('#gallery-count').textContent()).startsWith('2')) throw new Error('Gallery failed');
  await page.locator('#unit-contact').click();
  await page.screenshot({ path: resolve(out, 'detail-desktop.png') });
  for (let i = 0; i < 12; i++) {
    await page.keyboard.press('Tab');
    if (!await page.evaluate(() => document.querySelector('dialog').contains(document.activeElement))) throw new Error('Dialog focus escaped');
  }
  await page.keyboard.press('Escape');
  if (!await page.locator('[data-open-detail]').nth(1).evaluate(el => el === document.activeElement)) throw new Error('Focus restore failed');
  await page.locator('#contact-preview').click();
  if (!(await page.locator('#contact-feedback').textContent()).includes('no se abre WhatsApp')) throw new Error('Contact feedback failed');
  await page.evaluate(() => { document.body.style.zoom = '2'; window.scrollTo(0, 0); });
  if (await page.evaluate(() => document.documentElement.scrollWidth > innerWidth)) throw new Error('200% CSS zoom overflow');
  await page.screenshot({ path: resolve(out, 'zoom-200.png') });
  results.push({ interactions: 'route, filters, reset, reserved state, gallery, CTA feedback, focus trap, Escape, focus restoration passed', zoom: 'CSS 200%, no overflow; 768/390/320 viewports separately checked' });
  await page.close();
  const noJs = await browser.newPage({ javaScriptEnabled: false, viewport: { width: 390, height: 844 } });
  await noJs.goto(base);
  await noJs.getByRole('link', { name: 'Explorar vehículos', exact: true }).click();
  if (!noJs.url().endsWith('#catalogo')) throw new Error('No JS anchor failed');
  results.push({ noJs: 'Content and catalog anchor available. Interactive comparison and demo dialog intentionally JS-dependent.' });
  await noJs.close();
  await writeFile(resolve(out, 'results.json'), JSON.stringify(results, null, 2));
  console.log(JSON.stringify({ passed: true, checks: results.length, output: out }));
} finally { await browser.close(); }
