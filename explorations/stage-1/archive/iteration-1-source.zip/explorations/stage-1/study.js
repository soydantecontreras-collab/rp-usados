const root = document.documentElement;
const routes = new Set(['a', 'b', 'c']);
function setRoute(value) {
  if (!routes.has(value)) return;
  root.dataset.route = value;
  document.querySelector(`input[name="route"][value="${value}"]`).checked = true;
  const url = new URL(location.href);
  url.searchParams.set('ruta', value);
  history.replaceState(null, '', url);
}
setRoute(new URL(location.href).searchParams.get('ruta') || 'a');
document.querySelectorAll('input[name="route"]').forEach(input => input.addEventListener('change', () => setRoute(input.value)));
const form = document.querySelector('#filters');
const feedback = document.querySelector('#filter-feedback');
form.addEventListener('submit', event => {
  event.preventDefault();
  const active = [...new FormData(form).values()].some(value => String(value).trim());
  feedback.textContent = active ? 'Filtro probado. Esta exploración no tiene inventario: se mantienen las tres composiciones de muestra.' : 'Todos los filtros limpios · 3 composiciones de muestra, sin inventario conectado.';
});
document.querySelector('#reset').addEventListener('click', () => {
  form.reset(); feedback.textContent = 'Filtros restablecidos · 3 composiciones de muestra, sin inventario conectado.';
});
const dialog = document.querySelector('#detail');
let lastTrigger;
document.querySelectorAll('[data-open-detail]').forEach((button, index) => button.addEventListener('click', () => {
  lastTrigger = button;
  const state = document.querySelector('#detail-state');
  state.textContent = index === 1 ? 'Reservado · muestra' : 'Disponible · muestra';
  state.classList.toggle('reserved', index === 1);
  galleryIndex = 0; renderGallery();
  document.querySelector('#unit-feedback').textContent = 'En producción: WhatsApp con título y URL de la unidad. Número pendiente de confirmar.';
  dialog.showModal();
}));
document.querySelector('#close-detail').addEventListener('click', () => dialog.close());
dialog.addEventListener('close', () => lastTrigger?.focus());
dialog.addEventListener('keydown', event => {
  if (event.key !== 'Tab') return;
  const targets = [...dialog.querySelectorAll('button:not([disabled]), a[href], input, select')];
  const first = targets[0], last = targets.at(-1);
  if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
  else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
});
document.querySelector('#contact-preview').addEventListener('click', () => {
  document.querySelector('#contact-feedback').textContent = 'Vista previa: no se abre WhatsApp porque el número sigue pendiente. [dato pendiente — confirmar con el cliente]';
});
document.querySelector('#unit-contact').addEventListener('click', () => {
  document.querySelector('#unit-feedback').textContent = 'Vista previa del CTA por unidad. No se envía ningún mensaje. WhatsApp: [dato pendiente — confirmar con el cliente]';
});
let galleryIndex = 0;
const galleryViews = ['Vista exterior', 'Vista lateral', 'Interior'];
function renderGallery() {
  document.querySelector('#gallery-label').textContent = galleryViews[galleryIndex] + ' · foto pendiente';
  document.querySelector('#gallery-count').textContent = `${galleryIndex + 1} / 3 · vistas de muestra`;
}
document.querySelector('#gallery-prev').addEventListener('click', () => { galleryIndex = (galleryIndex + 2) % 3; renderGallery(); });
document.querySelector('#gallery-next').addEventListener('click', () => { galleryIndex = (galleryIndex + 1) % 3; renderGallery(); });
